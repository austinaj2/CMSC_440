Andre Austin
V#00827611
Programming Assignment #1

Handles all invalid arguments. 

To run the client, simply enter...
for GET request:
	python HTTPclient.py <URL>
for PUT requests:
	python HTTPclient.py PUT <URL> <path/desired file>

To run the server...
	python HTTPserver.py <port>
